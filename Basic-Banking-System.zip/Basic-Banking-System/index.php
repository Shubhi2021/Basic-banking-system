<!DOCTYPE html>
<html>
<head>
	<title>SVC Bank
  </title>
 <?php
include "includes/links.php";
  ?>
</head>
<body>
  <div class="ani">
      <h1>Bank at Your Fingerprints!!</h1>
  </div>
<div class="bg_img">
   
    <nav class="navbar navbar-expand-md navbar-light">

    <div class="container-fluid" style="padding-left: 140px; padding-right: 70px; padding-top: 30px;">
      
        <a class="navbar-brand" href="#"><h1><mark>SVC Bank</mark></h1></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active" style="padding-right: 50px;";>
            <a class="nav-link" href="home.php"><h3>Home</h3> <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item active" style="padding-right: -10px;">
            <a class="nav-link" href="aboutBank.php"><h3>about</h3></a>
            </li>
          </ul>

    </div>
   
   </nav>  

   

<br>
<br>
<br>
<br>
<br>
   <div class="container-fluid" style="padding-left: 120px;">
  <div class="btn-group-vertical" style = "width :250px; float: left;">
    <a href="details.php">
    <button type="button" class="btn btn-primary" style="width: 250px;"><h4>Users</h4></button>
  </a>
    <br>
    <br>
    <br>
    <a href="transfer.php">
    <button type="button" class="btn btn-primary btn-lg" style="width: 250px;"><h4>Transfer Funds</h4></button>
    </a><br>
    <br>
    <br>  
    <a href="transactions.php">
    <button type="button" class="btn btn-primary btn-lg" style="width: 250px;"><h4>Transactions</h4></button>
    </a> 
  </div>
</div>
</div>

  


  </body>
</html>